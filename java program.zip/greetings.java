public class greetings {

    public static void main(String[] args){
        String[] students = {"Alice", "Bob", "Charlie", "Diana", "Eve"};

        for (String student : students) {
            System.out.println("Hello, " + student + "!");
        }
    }
}
class Prints{
    public static void main(String[] args){
        System.out.println("first line");
        System.out.print("second line");
        System.out.println("third line");
        System.out.print("fourth line");

    }
}